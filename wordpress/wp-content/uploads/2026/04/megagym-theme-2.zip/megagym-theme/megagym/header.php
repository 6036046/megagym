<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<header class="main-header">
  <div class="logo">
    <?php
      if (function_exists('the_custom_logo')) {
        the_custom_logo();
      } else {
        ?>
        <a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo get_template_directory_uri(); ?>/logo.png" alt="MegaGym Logo"></a>
        <?php
      }
    ?>
  </div>

  <nav class="main-nav">
    <a href="#">Vind een club</a>
    <a href="#">Groepslessen</a>
    <a href="#">Training en advies</a>
  </nav>
</header>
