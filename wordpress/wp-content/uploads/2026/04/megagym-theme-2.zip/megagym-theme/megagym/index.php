<?php get_header(); ?>

<main class="site-main">
  <section class="hero-section">
    <div class="hero-content">
      <h1 class="hero-title">VERANDER JEZELF BIJ MEGAGYM</h1>
      <h2 class="hero-subtitle">KRACHT. UITVOERING. RESULTAAT.</h2>
      <a href="#" class="btn btn-primary">BEGIN VANDAAG</a>
    </div>
  </section>
</main>

<?php wp_footer(); ?>
</body>
</html>