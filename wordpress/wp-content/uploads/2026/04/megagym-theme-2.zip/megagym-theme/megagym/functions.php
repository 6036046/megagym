<?php
// Voeg ondersteuning toe voor thema-opties
function megagym_setup() {
    // Voeg ondersteuning toe voor aangepaste logo-ondersteuning
    add_theme_support('custom-logo');
}
add_action('after_setup_theme', 'megagym_setup');

// Enqueueer de CSS-bestanden en lettertypen
function megagym_styles() {
    // Importeer moderne lettertypen van Google Fonts
    wp_enqueue_style('megagym-fonts', 'https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap', array(), null);

    // Enqueueer het hoofd-stylesheet
    wp_enqueue_style('megagym-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'megagym_styles');
